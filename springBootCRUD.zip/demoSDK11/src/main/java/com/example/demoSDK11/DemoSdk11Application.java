package com.example.demoSDK11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSdk11Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoSdk11Application.class, args);
	}

}
